/*
https://contest.yandex.ru/contest/23815/run-report/115014959/

### Принцип работы

	Принцип работы заключен в разделении массива на части, их сортировка с последующим слиянием отсортированных частей,
	которые также сортируются - быстрая сортировка.

	В качестве функции разделении массива на части используется метод Ломуто:
	- В качестве опорного элемента всегда выбирается крайний правый элемент.
	- Так как выбирается всегда крайний правый элемент, в этом методе объявляется только одна переменная-указатель (i) для
	отслеживания индекса наибольшего элемента, который был меньше опорного.

	Программа в цикле обходит массив и каждый элемент сравнивает с опорным и, в случае,
	если текущий элемент меньше опорного она меняет его местами с элементом, на который указывает i.
	После завершении цикла меняет местами опорный элемент, с элементом на который указывает i+1.
	Функция разбиения partition возвращает индекс элемента, на котором закончилась сортировка, то есть i.

	Для сравнения элементов используется функция isGreater, в которой реализована логика сравнения.

### Доказательство корректности

	Алгоритм является вариацией быстрой сортировки с разбиением Ломуто и использованием функции-компаратора.

### Временная сложность

	При каждой итерации общая длина не отсортированного массива уменьшается на какую-то часть, таким образом получается, что:
	- Временная сложность - O(N*logn) - логарифмеческая
	Но в худшем случае, если элементы уже отсортированы или все элементы равны:
	- Временная сложность - O(N*N) - квадратичная

### Пространственная сложность

	В памяти  программы хранится только массив, который был передан во входных данных, таким образом получается, что:
	- Пространственная сложность - O(1)
*/
package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

func solution(ps []Participant) []Participant {
	return quickSortLomuto(ps, 0, len(ps)-1)
}

func quickSortLomuto(ps []Participant, left int, right int) []Participant {
	if len(ps) < 2 {
		return ps
	} else {
		if left < right {
			p := partitionLomuto(ps, left, right)

			ps = quickSortLomuto(ps, left, p-1)
			ps = quickSortLomuto(ps, p+1, right)
		}
	}

	return ps
}

func partitionLomuto(ps []Participant, left int, right int) int {
	pivot := ps[right]
	i := left
	for j := left; j < right; j++ {
		if ps[j].isGreater(pivot) {
			ps[i], ps[j] = ps[j], ps[i]
			i++
		}
	}
	ps[i], ps[right] = ps[right], ps[i]
	return i
}

func (p Participant) isGreater(j Participant) bool {
	if p.solved > j.solved {
		return true
	} else if (p.solved == j.solved) && (p.fine < j.fine) {
		return true
	} else if (p.solved == j.solved) && (p.fine == j.fine) {
		return p.name < j.name
	}

	return false
}

type Participant struct {
	name   string
	solved int
	fine   int
}

func main() {
	scanner := makeScanner()
	ps := readInput(scanner)
	printArray(solution(ps))
}

func makeScanner() *bufio.Scanner {
	const maxCapacity = 64 * 1024 * 1024
	buf := make([]byte, maxCapacity)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(buf, maxCapacity)
	return scanner
}

func printArray(ps []Participant) {
	writer := bufio.NewWriter(os.Stdout)
	for i := 0; i < len(ps); i++ {
		writer.WriteString(ps[i].name)
		writer.WriteString("\n")
	}
	writer.Flush()
}

func readInput(scanner *bufio.Scanner) []Participant {
	scanner.Scan()
	stringInt := scanner.Text()
	n, _ := strconv.Atoi(stringInt)

	arr := make([]Participant, n)
	for i := 0; i < n; i++ {
		scanner.Scan()
		listString := strings.Split(scanner.Text(), " ")

		solved, _ := strconv.Atoi(listString[1])
		fine, _ := strconv.Atoi(listString[2])

		arr[i] = Participant{
			name:   listString[0],
			solved: solved,
			fine:   fine,
		}
	}
	return arr
}
