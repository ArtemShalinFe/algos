package main

import (
	"testing"
)

func Test_remove(t *testing.T) {
	test()
}
