/*
https://contest.yandex.ru/contest/25070/run-report/116435541/

### Принцип работы

	Алгоритм представляет карту железных дорог в виду графа, у которого вершины - это города, а ребра - дороги между городами.
	Причем, дороги типа R - будут являться прямыми дорогами от одного города к другому, а дороги типа B - будут являться
	обратными дорогами между этими же городами.

	Идея заключается в том, чтобы использовать алгоритм поиска в глубину (DFS) для обхода графа и проверять, что между
	парами вершин нет циклов.

### Доказательство корректности

	В качестве механизма определения посещенных вершин, алгоритм использует цвета:
	- white вершина еще не посещена, является значением по умолчанию;
	- gray - вершина посещена, но обработаны не все ее ребра, устанавливается этот цвет когда алгоритм впервые посещает вершину;
	- black - вершина посещена и все ее ребра обработаны.

	Алгоритм обходит граф и, если во время обхода графа он встречает вершину цвета `gray`, это означает, что вершина была
	посещена ранее в текущем обходе и в графе есть цикл. А цикл в графе в свою очередь говоритм алгоритму о том, что
	между вершинами графа существует несколько путей разных типов, а значит предлагаемая карта неоптимальная.

### Временная сложность

	Временная сложность складывается из:
	- Построения матрицы смежности состоящей из городов (N) и дорог (J), которая в сумме составляет O(N*J).
	- Обход графа в глубину О(N+J), где города (N), а дороги (J)

	Итого:
	- Временная сложность - O(N*J)+О(N+J)

### Пространственная сложность

	В памяти программы хранится:
	- Матрица смежности в которой N^2 городов.
	- Список посещенных вершин длинной K.
	- При обходе графа программа хранит в памяти стек M.

	Итого:
	- Временная сложность - O(N^2 + K + M)
*/
package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

func solution(n int, mor *MatrixOfRailways) bool {
	for i := 1; i <= n; i++ {
		if mor.colors[i] != "white" {
			continue
		}

		stack := []int{i}
		for len(stack) > 0 {
			v := stack[len(stack)-1]

			if mor.colors[v] == "white" {
				mor.colors[v] = "gray"

				for i := 0; i < len(mor.mx[v]); i++ {
					u := mor.mx[v][i]
					switch mor.colors[u] {
					case "white":
						stack = append(stack, u)
					case "gray":
						return false
					}
				}
			} else {
				mor.colors[v] = "black"
				stack = stack[:len(stack)-1]
			}
		}
	}

	return true
}

func main() {
	scanner := makeScanner()
	n := readInt(scanner)
	mor := readArray(n, scanner)
	printRes(solution(n, mor))
}

func makeScanner() *bufio.Scanner {
	const maxCapacity = 3 * 1024 * 1024
	buf := make([]byte, maxCapacity)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(buf, maxCapacity)
	return scanner
}

func printRes(res bool) {
	writer := bufio.NewWriter(os.Stdout)
	if res {
		writer.WriteString("YES")
	} else {
		writer.WriteString("NO")
	}
	writer.Flush()
}

type MatrixOfRailways struct {
	mx     [][]int
	colors []string
}

func readArray(n int, scanner *bufio.Scanner) *MatrixOfRailways {
	mor := &MatrixOfRailways{
		mx:     make([][]int, n+1),
		colors: make([]string, n+1),
	}

	for i := 1; i < n; i++ {
		scanner.Scan()

		list := strings.Split(scanner.Text(), "")
		for j := 0; j < len(list); j++ {
			target := i + j + 1
			if list[j] == "R" {
				mor.mx[i] = append(mor.mx[i], target)
				mor.colors[i] = "white"
			} else {
				mor.mx[target] = append(mor.mx[target], i)
				mor.colors[target] = "white"
			}
		}
	}

	return mor
}

func readInt(scanner *bufio.Scanner) int {
	scanner.Scan()
	stringInt := scanner.Text()
	res, _ := strconv.Atoi(stringInt)
	return res
}
