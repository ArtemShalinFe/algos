/*
https://contest.yandex.ru/contest/25070/run-report/116435534/

### Принцип работы

	Основная идея заключается в том, чтобы представить схему офиса в виде неориентированного графа. После чего найти вес
	максимального остовного дерева. При обходе графа алгоритм будет использовать такую структуру данных как приоритетная очередь,
	чтобы в качестве следующего ребра использовать ребро с максимальным весом.

### Доказательство корректности

	Алгоритм обходит граф до тех пор пока все связанные вершины не будут включены в максимальное остовного дерево.
	Во время обхода графа, благодаря приоритетной очереди, алгоритм всегда будет выбирать ребро с максимальным весом.
	В итоге алгоритм обойдет все связанные вершины по ребрам с максимальными весами и посчитает вес MST.

	Если после обхода графа имеются не посещенные вершины, то в графе есть несколько компонентов связности и программа выведет
	`Oops! I did it again`.

### Временная сложность

	Временная сложность состоит из:
	- Построения матрицы смежности O(V+E) из вершин (V) и ребер (E)
	- Нахождения максимального остовного дерева O(V+E) во время обхода графа программа добавляет и забирает ребро из
	приоритетной очереди за log E.

	Итого временная сложность:
	- O(V+E) + O(V+E*logE)

### Пространственная сложность

	В памяти программы хранится:
	- Матрица смежности, в которой N^2 вершин.
	- Хеш таблица посещенных вершин К
	- Приоритетная очередь на массиве размера М

	Итого пространственная сложность:
	- N^2 + К + М
*/
package main

import (
	"bufio"
	"os"
	"strconv"
	"strings"
)

func solution(mx [][]*Edge) string {
	var ans int
	if len(mx) == 0 {
		return "0"
	}
	pq := makeHeap()
	visited := make(map[int]bool, 0)

	visited[len(mx)-1] = true
	for i := 0; i < len(mx[len(mx)-1]); i++ {
		e := mx[len(mx)-1][i]
		if vstd, ok := visited[e.NodeID]; ok && vstd {
			continue
		}
		pq.Push(e)
	}

	for pq.Len() > 0 {
		maxEdge := pq.PopMax()
		if vstd, ok := visited[maxEdge.NodeID]; ok && vstd {
			continue
		}
		ans += maxEdge.Weight
		visited[maxEdge.NodeID] = true

		for i := 0; i < len(mx[maxEdge.NodeID]); i++ {
			e := mx[maxEdge.NodeID][i]
			if vstd, ok := visited[e.NodeID]; ok && vstd {
				continue
			}
			pq.Push(e)
		}
	}

	if len(visited) != len(mx)-1 {
		return "Oops! I did it again"
	}

	return strconv.Itoa(ans)
}

func readArray(scanner *bufio.Scanner) (int, int, [][]*Edge) {
	scanner.Scan()
	listString := strings.Split(scanner.Text(), " ")

	n, _ := strconv.Atoi(listString[0])
	m, _ := strconv.Atoi(listString[1])

	mx := make([][]*Edge, n+1)
	for i := 1; i <= n; i++ {
		mx[i] = make([]*Edge, 0)
	}

	for j := 1; j <= m; j++ {
		scanner.Scan()
		listString := strings.Split(scanner.Text(), " ")

		from, _ := strconv.Atoi(listString[0])
		to, _ := strconv.Atoi(listString[1])
		w, _ := strconv.Atoi(listString[2])

		if from == to {
			continue
		}

		mx[from] = append(mx[from], &Edge{NodeID: to, Weight: w})
		mx[to] = append(mx[to], &Edge{NodeID: from, Weight: w})
	}

	return n, m, mx
}

type Edge struct {
	NodeID int
	Weight int
}

func (e *Edge) isLower(j *Edge) bool {
	return e.Weight < j.Weight
}

type PriorityQueue struct {
	heap []*Edge
}

func makeHeap() *PriorityQueue {
	return &PriorityQueue{
		heap: make([]*Edge, 0),
	}
}

func (pq *PriorityQueue) Push(e *Edge) {
	pq.heap = append(pq.heap, e)
	pq.siftUp(pq.Len() - 1)
}

func (pq *PriorityQueue) Len() int {
	return len(pq.heap)
}

func (pq *PriorityQueue) PopMax() *Edge {
	result := pq.heap[0]
	pq.heap[0] = pq.heap[len(pq.heap)-1]
	pq.siftDown(0)
	pq.heap = pq.heap[:len(pq.heap)-1]

	return result
}

func (pq *PriorityQueue) siftDown(idx int) {
	for {
		left := 2 * idx
		right := 2*idx + 1

		if left >= len(pq.heap) {
			break
		}
		idxLrg := left
		if right < len(pq.heap) && pq.heap[left].isLower(pq.heap[right]) {
			idxLrg = right
		}

		if !pq.heap[idx].isLower(pq.heap[idxLrg]) {
			break
		}

		pq.heap[idx], pq.heap[idxLrg] = pq.heap[idxLrg], pq.heap[idx]
		idx = idxLrg
	}
}

func (pq *PriorityQueue) siftUp(idx int) int {
	if idx == 0 {
		return idx
	}

	for {
		parentIndex := idx / 2
		if !pq.heap[parentIndex].isLower(pq.heap[idx]) {
			break
		}
		pq.heap[parentIndex], pq.heap[idx] = pq.heap[idx], pq.heap[parentIndex]

		idx = parentIndex
	}

	return idx
}

func main() {
	scanner := makeScanner()
	n, m, list := readArray(scanner)
	if n > 1 && m == 0 {
		printAns("Oops! I did it again")
		return
	}
	printAns(solution(list))
}

func makeScanner() *bufio.Scanner {
	const maxCapacity = 3 * 1024 * 1024
	buf := make([]byte, maxCapacity)
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Buffer(buf, maxCapacity)
	return scanner
}

func printAns(ans string) {
	writer := bufio.NewWriter(os.Stdout)
	writer.WriteString(ans)
	writer.Flush()
}
